***************************
Freescale i.MX6UL EVK board
***************************

This file documents the Buildroot support for the Freescale i.MX6UL EVK board.

Please read the i.MX6UL Evaluation Kit Quick Start Guide [1] for an
introduction to the board.

Build
=====

First, configure Buildroot for your i.MX6UL EVK board:

In order to do so there are two supported options:

  make freescale_imx6ulevk_defconfig

if you plan to use NXP provided U-Boot and kernel.

or

  make imx6ulevk_defconfig

if you plan to use mainline U-Boot and mainline kernel.

Build all components:

  make

You will find in ./output/images/ the following files:
  - imx6ul-14x14-evk.dtb
  - rootfs.ext4
  - rootfs.tar
  - sdcard.img
  - u-boot.imx
  - zImage

Create a bootable microSD card
==============================

To determine the device associated to the microSD card have a look in the
/proc/partitions file:

  cat /proc/partitions

Buildroot prepares a bootable "sdcard.img" image in the output/images/
directory, ready to be dumped on a microSD card. Launch the following
command as root:

  dd if=./output/images/sdcard.img of=/dev/<your-microsd-device>

*** WARNING! This will destroy all the card content. Use with care! ***

For details about the medium image layout, see the definition in
board/freescale/common/imx/genimage.cfg.template.

Boot the i.MX6UL EVK board
=========================

To boot your newly created system (refer to the i.MX6UL EVK Quick Start Guide
[1] for guidance):
- insert the microSD card in the microSD slot of the board;
- verify that your i.MX6UL EVK board jumpers and switches are set as mentioned
  in the i.MX6UL EVK Quick Start Guide [1];
- put a micro USB cable into the Debug USB Port and connect using a terminal
  emulator at 115200 bps, 8n1;
- power on the board.

Enjoy!

References
==========
[1] https://www.nxp.com/webapp/Download?colCode=IMX6ULTRALITEQSG
